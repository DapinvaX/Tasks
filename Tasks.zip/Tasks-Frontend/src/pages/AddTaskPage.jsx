import TasksForm from "../components/TasksForm";

function AddTaskPage(){

    return (
        
        <div>
            <h1>Añadir Task</h1>
            <TasksForm/>
        </div>
       
    );

}
export default AddTaskPage;