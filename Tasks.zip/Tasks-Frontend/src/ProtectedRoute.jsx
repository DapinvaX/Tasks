import { useAuthProfile } from "./context/AuthContextProfile.jsx";

import { Navigate, Outlet } from 'react-router-dom';

function ProtectedRoute() {

    //Si encuentra un token en las cookies, se autentica al usuario
    const { auth } = useAuthProfile();
    
    if (!auth) {
        return <Navigate to="/login" />
    }

    return (
        <Outlet />
    )

}
export default ProtectedRoute;