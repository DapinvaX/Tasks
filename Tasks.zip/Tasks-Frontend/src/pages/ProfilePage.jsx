function ProfilePage() {
    return (
        
        <div>
            <h1>Profile Page</h1>
        </div>

    )
}
export default ProfilePage;