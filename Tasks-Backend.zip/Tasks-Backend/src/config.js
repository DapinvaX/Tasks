//Guardamos el TOKEN_SECRET en una variable para poder exportarlo y usarlo en otros archivos
export const TOKEN_SECRET = 'MySecretKeyDPX';